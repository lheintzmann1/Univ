#! /bin/sh

echo "Je suis un script cache !"
exit 0
