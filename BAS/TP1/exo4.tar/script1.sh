#! /bin/sh

echo "Ceci est le script 1"
exit 0
