# Faire la somme de deux entiers saisis par l'utilisateur
# Saisie des deux entiers
n1 = int(input("Veuillez entre un entier "))
n2 = int(input("Veuillez entre un autre entier "))
# Calcul de la somme
somme = n1 + n2
#Affichage du resultat
print("Somme de ", n1, " et ", n2, " = ", somme)

