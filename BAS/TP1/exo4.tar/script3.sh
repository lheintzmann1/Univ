#! /bin/sh

echo "Ceci est le script 3"
echo "La date du jour est "
date

exit 0
