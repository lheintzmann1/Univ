# Faire le produit de deux entiers saisis par l'utilisateur
# Saisie des deux entiers
n1 = int(input("Veuillez entre un entier "))
n2 = int(input("Veuillez entre un autre entier "))
# Calcul du produit
produit = n1 * n2
#Affichage du resultat
print("Produit de ", n1, " et ", n2, " = ", produit)

