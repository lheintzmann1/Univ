#! /bin/sh

echo "Ceci est le script 2"
exit 0
