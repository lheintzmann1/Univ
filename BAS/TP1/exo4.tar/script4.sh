#! /bin/sh

echo "Ceci est le script 4 qui se trouve sous"
pwd

exit 0
